#!/bin/sh

echo "Uninstalling Light Point Web"
echo "Unregistering Firefox extension"
for extDestDir in "/usr/lib64/mozilla/extensions/{ec8030f7-c20a-464f-9b0e-13a3a9e97384}" \
                "/usr/lib/mozilla/extensions/{ec8030f7-c20a-464f-9b0e-13a3a9e97384}" \
                "/usr/lib64/mozilla/extensions" \
                "/usr/lib/mozilla/extensions" \
                "/usr/lib/firefox/browser/extensions" \
				"/usr/share/mozilla/extensions/{ec8030f7-c20a-464f-9b0e-13a3a9e97384}"
do
	if [ -e $extDestDir ]
	then
		echo "Unregistering Legacy Firefox extension in $extDestDir"
		rm -f $extDestDir/lightpointweb@lightpointsecurity.com

		echo "Unregistering Modern Firefox extension in $extDestDir"
		rm -f $extDestDir/lightpointweb2@lightpointsecurity.com
	fi
done

echo "Removing Firefox Native Messaging Helper"
rm -f /usr/lib/mozilla/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json

echo "Removing Chrome Native Messaging Helper"
rm -f /etc/opt/chrome/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json
rm -f /etc/chromium/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json

echo "Removing Chrome Extension"
rm -f /usr/share/google-chrome/extensions/dggppplhkpknjnpcdhfpngmbpdmhpkee.json
rm -f /usr/share/chromium/extensions/dggppplhkpknjnpcdhfpngmbpdmhpkee.json

echo "Unregistering browser plugin"
for pluginDestDir in "/usr/lib64/mozilla/plugins" \
                    "/usr/lib/mozilla/plugins" \
                    "/usr/lib/firefox/browser/plugins"
do
	if [ -e $pluginDestDir ]
	then
		echo "Unregistering plugin in $pluginDestDir"
                rm -f $pluginDestDir/npLightPointWeb.so
	fi
done

echo "Removing installation directory"
installdir="/usr/bin/lightpointweb"
rm -rf $installdir
