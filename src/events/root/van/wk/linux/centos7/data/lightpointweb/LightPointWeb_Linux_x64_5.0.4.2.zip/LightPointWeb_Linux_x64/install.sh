#!/bin/sh

echo "Installing Light Point Web"

srcdir="./LinuxInstallFiles"
rm -rf $srcdir

echo "Decompressing install files"
tar -xSf ./$srcdir.tar.gz

installdir="/usr/bin/lightpointweb"
mkdir -p $installdir
rm -rf $installdir/*

echo "Copying in installation files"
cp -r $srcdir/bin $installdir/
cp -r $srcdir/firefox $installdir/
cp -r $srcdir/chrome $installdir/
cp -r $srcdir/plugin $installdir/

echo "Correcting file permissions"
chmod 755 $installdir/bin/*
chmod 755 $installdir/firefox/helper/lpw_firefox_helper
chmod 755 $installdir/chrome/lpw_chrome_helper
chmod 755 $installdir/plugin/*

settingsDir="/etc/lightpointweb"
mkdir -p $settingsDir
if [ -e "$settingsDir/settings.cfg" ]
then
	echo "Systems settings file already exists"
else
	echo "Adding example system settings file"
	cp $srcdir/settings.cfg $settingsDir/
fi

echo "Cleaning up temp files"
rm -rf $srcdir

for extDestDir in "/usr/lib64/mozilla/extensions/{ec8030f7-c20a-464f-9b0e-13a3a9e97384}" \
                "/usr/lib/mozilla/extensions/{ec8030f7-c20a-464f-9b0e-13a3a9e97384}" \
				"/usr/lib64/mozilla/extensions" \
                "/usr/lib/mozilla/extensions" \
                "/usr/lib/firefox/browser/extensions" \
				"/usr/share/mozilla/extensions/{ec8030f7-c20a-464f-9b0e-13a3a9e97384}"
do
	if [ -e $extDestDir ]
	then
		echo "Registering Legacy Firefox extension in $extDestDir"
		rm -f $extDestDir/lightpointweb@lightpointsecurity.com
		ln -sf $installdir/firefox/extension $extDestDir/lightpointweb@lightpointsecurity.com

		echo "Registering Modern Firefox extension in $extDestDir"
		rm -f $extDestDir/lightpointweb2@lightpointsecurity.com
		ln -sf $installdir/firefox/webExtension $extDestDir/lightpointweb2@lightpointsecurity.com
	fi
done

echo "Registering Firefox Native Messaging Helper"
mkdir -p /usr/lib/mozilla/native-messaging-hosts
rm -f /usr/lib/mozilla/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json
ln -s $installdir/firefox/helper/nmh_manifest.json /usr/lib/mozilla/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json

echo "Registering Chrome Native Messaging Helper"
mkdir -p /etc/opt/chrome/native-messaging-hosts
mkdir -p /etc/chromium/native-messaging-hosts
rm -f /etc/opt/chrome/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json
rm -f /etc/chromium/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json
ln -s $installdir/chrome/nmh_manifest.json /etc/opt/chrome/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json
ln -s $installdir/chrome/nmh_manifest.json /etc/chromium/native-messaging-hosts/com.lightpointsecurity.lightpointweb.json

echo "Registering Chrome Extension"
mkdir -p /usr/share/google-chrome/extensions/
mkdir -p /usr/share/chromium/extensions/
rm -f /usr/share/google-chrome/extensions/dggppplhkpknjnpcdhfpngmbpdmhpkee.json
rm -f /usr/share/chromium/extensions/dggppplhkpknjnpcdhfpngmbpdmhpkee.json
ln -s $installdir/chrome/dggppplhkpknjnpcdhfpngmbpdmhpkee.json /usr/share/google-chrome/extensions/dggppplhkpknjnpcdhfpngmbpdmhpkee.json
ln -s $installdir/chrome/dggppplhkpknjnpcdhfpngmbpdmhpkee.json /usr/share/chromium/extensions/dggppplhkpknjnpcdhfpngmbpdmhpkee.json

echo "Installing browser plugin"
mkdir -p /usr/lib/mozilla/plugins
for pluginDestDir in "/usr/lib64/mozilla/plugins" \
                    "/usr/lib/mozilla/plugins" \
                    "/usr/lib/firefox/browser/plugins"
do
	if [ -e $pluginDestDir ]
	then
		echo "Registering plugin in $pluginDestDir"
                rm -f $pluginDestDir/npLightPointWeb.so
                ln -sf $installdir/plugin/npLightPointWeb.so $pluginDestDir/npLightPointWeb.so
	fi
done

echo "Installing dependencies"
if [ -x "/usr/bin/apt-get" ]
then
	/usr/bin/apt-get install libqtwebkit4 -y
	/usr/bin/apt-get install libpng12-0 libjpeg62 -y
elif [ -x "/usr/bin/yum" ]
then
	/usr/bin/yum install epel-release -y
	/usr/bin/yum install qtwebkit libpng12 -y
else
	echo "Unsupported package system. Please ensure 'libqtwebkit4' and 'libpng12' packages are installed"
fi

exit 0
